// Web Speech API Integration for Guided Sleep Audio
class SpeechGuide {
    constructor() {
        this.speech = null;
        this.isSpeaking = false;
        this.guides = {
            sleep: [
                "Find a comfortable position in your bed",
                "Close your eyes gently",
                "Take a deep breath in through your nose... 1... 2... 3... 4...",
                "Hold your breath... 1... 2... 3... 4... 5... 6... 7...",
                "Slowly exhale through your mouth... 1... 2... 3... 4... 5... 6... 7... 8...",
                "Feel your body relaxing with each exhale",
                "Starting from your toes, feel them relax completely",
                "Your feet are relaxed and heavy",
                "Your ankles are loose and calm",
                "Your calves are soft and at ease",
                "Your knees are supported and peaceful",
                "Your thighs are completely relaxed",
                "Your hips are sinking into the bed",
                "Your stomach is soft and calm",
                "Your chest rises and falls with each gentle breath",
                "Your shoulders release all tension",
                "Your arms feel heavy and relaxed",
                "Your hands are open and peaceful",
                "Your neck is loose and comfortable",
                "Your jaw is unclenched, your lips slightly apart",
                "Your face muscles are completely relaxed",
                "Your forehead is smooth and calm",
                "Your mind is quiet, thoughts drifting away like clouds",
                "With each breath, you sink deeper into relaxation",
                "You are safe, you are calm, you are at peace",
                "Sleep is coming naturally and easily",
                "You will sleep deeply and wake refreshed"
            ],
            quickCalm: [
                "Let's take a moment to calm your mind",
                "Place one hand on your chest, one on your stomach",
                "Breathe in slowly... 1... 2... 3... 4...",
                "Feel your stomach rise under your hand",
                "Hold... 1... 2... 3... 4...",
                "Breathe out slowly... 1... 2... 3... 4... 5... 6...",
                "Again, breathe in peace... 1... 2... 3... 4...",
                "Hold the calm... 1... 2... 3... 4...",
                "Release tension... 1... 2... 3... 4... 5... 6...",
                "You are becoming more relaxed with each breath"
            ],
            panicHelp: [
                "You are having a panic attack, but you are safe",
                "This feeling will pass, I promise",
                "Let's focus on your breathing together",
                "Breathe in with me... 1... 2... 3... 4...",
                "Hold... 1... 2... 3... 4... 5... 6... 7...",
                "Breathe out slowly... 1... 2... 3... 4... 5... 6... 7... 8...",
                "You're doing great, keep breathing with me",
                "In... 1... 2... 3... 4...",
                "Hold... 1... 2... 3... 4... 5... 6... 7...",
                "Out... 1... 2... 3... 4... 5... 6... 7... 8...",
                "You are safe, you are here, this is passing"
            ]
        };
    }

    init() {
        if ('speechSynthesis' in window) {
            this.speech = window.speechSynthesis;

            // Set up speech controls
            this.setupControls();
            return true;
        }
        return false;
    }

    setupControls() {
        // Add speech controls to the UI
        const sleepPanel = document.querySelector('.sleep-panel');
        const speechDiv = document.createElement('div');
        speechDiv.className = 'speech-guide';
        speechDiv.innerHTML = `
            <h3><i class="fas fa-microphone-alt"></i> Guided Sleep Audio</h3>
            <div class="speech-controls">
                <button id="startSpeech" class="btn-primary">
                    <i class="fas fa-play"></i> Start Guided Sleep
                </button>
                <button id="stopSpeech" class="btn-secondary">
                    <i class="fas fa-stop"></i> Stop Guide
                </button>
                <select id="guideSelect">
                    <option value="sleep">Full Sleep Guide</option>
                    <option value="quickCalm">Quick Calm</option>
                    <option value="panicHelp">Panic Assistance</option>
                </select>
            </div>
            <div class="speech-status">
                <p id="speechStatus">Ready to guide you</p>
            </div>
        `;

        // Insert after breathing exercise
        const breathingSection = sleepPanel.querySelector('.breathing-exercise');
        breathingSection.parentNode.insertBefore(speechDiv, breathingSection.nextSibling);

        // Add event listeners
        document.getElementById('startSpeech').addEventListener('click', () => this.startGuide());
        document.getElementById('stopSpeech').addEventListener('click', () => this.stopGuide());

        // Also connect panic button to speech
        document.getElementById('panicButton').addEventListener('click', () => {
            document.getElementById('guideSelect').value = 'panicHelp';
            setTimeout(() => this.startGuide(), 1000);
        });
    }

    startGuide(type = null) {
        if (this.isSpeaking) {
            this.stopGuide();
            return;
        }

        const guideType = type || document.getElementById('guideSelect').value;
        const messages = this.guides[guideType];

        if (!messages || !this.speech) return;

        this.isSpeaking = true;
        document.getElementById('speechStatus').textContent = 'Speaking...';
        document.getElementById('startSpeech').innerHTML = '<i class="fas fa-pause"></i> Pause Guide';

        this.speakMessages(messages, 0);
    }

    speakMessages(messages, index) {
        if (index >= messages.length || !this.isSpeaking) {
            this.isSpeaking = false;
            document.getElementById('speechStatus').textContent = 'Guide complete';
            document.getElementById('startSpeech').innerHTML = '<i class="fas fa-play"></i> Start Guided Sleep';
            return;
        }

        const utterance = new SpeechSynthesisUtterance(messages[index]);

        // Set voice properties
        utterance.rate = 0.8;
        utterance.pitch = 1;
        utterance.volume = 1;

        // Try to get a calming voice
        const voices = this.speech.getVoices();
        const femaleVoice = voices.find(v => v.name.includes('Female') || v.name.includes('Samantha'));
        if (femaleVoice) {
            utterance.voice = femaleVoice;
        }

        utterance.onend = () => {
            // Pause between messages
            setTimeout(() => {
                this.speakMessages(messages, index + 1);
            }, 1500);
        };

        utterance.onerror = (event) => {
            console.error('Speech error:', event);
            this.isSpeaking = false;
            document.getElementById('speechStatus').textContent = 'Error occurred';
            document.getElementById('startSpeech').innerHTML = '<i class="fas fa-play"></i> Start Guided Sleep';
        };

        this.speech.speak(utterance);
    }

    stopGuide() {
        this.isSpeaking = false;
        this.speech.cancel();
        document.getElementById('speechStatus').textContent = 'Stopped';
        document.getElementById('startSpeech').innerHTML = '<i class="fas fa-play"></i> Start Guided Sleep';
    }

    // Quick calm function for emergency buttons
    quickCalm() {
        this.startGuide('quickCalm');
    }
}

// Initialize Speech Guide when page loads
document.addEventListener('DOMContentLoaded', function() {
    const speechGuide = new SpeechGuide();
    const speechAvailable = speechGuide.init();

    if (!speechAvailable) {
        console.log('Speech synthesis not available');
        // Hide speech controls if not available
        const speechControls = document.querySelector('.speech-guide');
        if (speechControls) {
            speechControls.style.display = 'none';
        }
    }
});