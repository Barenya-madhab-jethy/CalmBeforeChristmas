// Global Variables
let currentMood = 3;
let calmScore = 75;
let streak = 0;
let isNightMode = false;
let snowEnabled = true;
let currentAudio = null;
let sleepTimer = null;
let selectedRating = 0;

// Initialize the app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    createSnowflakes();
    loadFromLocalStorage();
    updateUI();
});

function initializeApp() {
    // Night Mode Toggle
    document.getElementById('nightModeToggle').addEventListener('click', toggleNightMode);

    // Snow Toggle
    document.getElementById('snowToggle').addEventListener('click', toggleSnow);

    // Audio Controls
    setupAudioControls();

    // Breathing Exercise
    document.getElementById('startBreathing').addEventListener('click', startBreathingExercise);

    // Sleep Rating
    setupSleepRating();

    // Bedtime Reminder
    document.getElementById('setReminder').addEventListener('click', setBedtimeReminder);

    // Anxiety Quiz
    document.getElementById('startQuiz').addEventListener('click', startAnxietyQuiz);

    // Emergency Buttons
    document.getElementById('panicButton').addEventListener('click', showPanicHelp);
    document.getElementById('notOkayButton').addEventListener('click', showImNotOkaySupport);

    // Grounding Exercise
    document.getElementById('startGrounding').addEventListener('click', startGroundingExercise);

    // Mood Tracker
    setupMoodTracker();

    // Festive Features
    document.getElementById('newMessage').addEventListener('click', generateSantaMessage);
    document.getElementById('newQuote').addEventListener('click', generateNewQuote);

    // AI Support
    document.getElementById('getAiResponse').addEventListener('click', getAIResponse);

    // Report Export
    document.getElementById('viewReport').addEventListener('click', showWeeklyReport);
    document.getElementById('exportReport').addEventListener('click', exportReport);

    // Initialize festive elements
    generateSantaMessage();
    generateNewQuote();

    // Check for notifications permission
    if ('Notification' in window) {
        Notification.requestPermission();
    }
}

// Snow Effects
function createSnowflakes() {
    const container = document.getElementById('snow-container');
    if (!snowEnabled) {
        container.innerHTML = '';
        return;
    }

    // Create 50 snowflakes
    for (let i = 0; i < 50; i++) {
        const snowflake = document.createElement('div');
        snowflake.classList.add('snowflake');

        // Random size between 5 and 15px
        const size = Math.random() * 10 + 5;
        snowflake.style.width = `${size}px`;
        snowflake.style.height = `${size}px`;

        // Random position
        snowflake.style.left = `${Math.random() * 100}%`;
        snowflake.style.top = `${Math.random() * -20}px`;

        // Random opacity
        snowflake.style.opacity = Math.random() * 0.8 + 0.2;

        // Random animation duration
        const duration = Math.random() * 10 + 10;
        snowflake.style.animationDuration = `${duration}s`;

        // Random animation delay
        snowflake.style.animationDelay = `${Math.random() * 5}s`;

        container.appendChild(snowflake);
    }
}

function toggleSnow() {
    snowEnabled = !snowEnabled;
    const button = document.getElementById('snowToggle');
    if (snowEnabled) {
        button.innerHTML = '<i class="fas fa-snowflake"></i> Hide Snow';
        createSnowflakes();
    } else {
        button.innerHTML = '<i class="fas fa-snowflake"></i> Show Snow';
        document.getElementById('snow-container').innerHTML = '';
    }
}

// Night Mode
function toggleNightMode() {
    isNightMode = !isNightMode;
    document.body.classList.toggle('night-mode', isNightMode);
    saveToLocalStorage();
}

// Audio Controls
function setupAudioControls() {
    const playBtn = document.getElementById('playBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const stopBtn = document.getElementById('stopBtn');
    const volumeSlider = document.getElementById('volumeSlider');
    const audioSelect = document.getElementById('audioSelect');
    const sleepTimerSelect = document.getElementById('sleepTimer');

    // Audio files mapping
    const audioFiles = {
        christmasLullaby: 'https://assets.mixkit.co/music/preview/mixkit-christmas-lullaby-232.mp3',
        rainSounds: 'https://assets.mixkit.co/sfx/preview/mixkit-rain-loop-1249.mp3',
        firewood: 'https://assets.mixkit.co/sfx/preview/mixkit-burning-fireplace-1351.mp3',
        snowfall: 'https://assets.mixkit.co/sfx/preview/mixkit-cold-wind-snow-loop-1251.mp3',
        whiteNoise: 'https://assets.mixkit.co/sfx/preview/mixkit-wind-in-the-trees-1325.mp3'
    };

    const audioPlayer = document.getElementById('audioPlayer');

    playBtn.addEventListener('click', () => {
        const selectedAudio = audioSelect.value;
        audioPlayer.src = audioFiles[selectedAudio];
        audioPlayer.play().catch(e => console.log('Audio play failed:', e));
    });

    pauseBtn.addEventListener('click', () => audioPlayer.pause());
    stopBtn.addEventListener('click', () => {
        audioPlayer.pause();
        audioPlayer.currentTime = 0;
    });

    volumeSlider.addEventListener('input', (e) => {
        audioPlayer.volume = e.target.value / 100;
    });

    sleepTimerSelect.addEventListener('change', (e) => {
        const minutes = parseInt(e.target.value);
        if (sleepTimer) clearTimeout(sleepTimer);

        if (minutes > 0) {
            sleepTimer = setTimeout(() => {
                audioPlayer.pause();
                audioPlayer.currentTime = 0;
                showNotification('Sleep Timer', 'Your sleep timer has ended. Good night! 🎄');
            }, minutes * 60 * 1000);
        }
    });
}

// Breathing Exercise
function startBreathingExercise() {
    const circle = document.getElementById('breathingCircle');
    const button = document.getElementById('startBreathing');

    if (button.textContent.includes('Start')) {
        button.innerHTML = '<i class="fas fa-pause"></i> Stop Breathing';
        circle.style.animation = 'breathe 8s infinite ease-in-out';

        // Guide the user through 4-7-8 breathing
        let cycle = 0;
        const guideInterval = setInterval(() => {
            cycle++;
            const phase = cycle % 3;
            if (phase === 0) {
                circle.querySelector('span').textContent = 'Breathe In (4s)';
            } else if (phase === 1) {
                circle.querySelector('span').textContent = 'Hold (7s)';
            } else {
                circle.querySelector('span').textContent = 'Breathe Out (8s)';
            }

            if (cycle >= 6) { // Do 2 complete cycles
                clearInterval(guideInterval);
                circle.querySelector('span').textContent = 'Complete!';
                setTimeout(() => {
                    button.innerHTML = '<i class="fas fa-play"></i> Start 4-7-8 Breathing';
                    circle.style.animation = 'none';
                    circle.querySelector('span').textContent = 'Breathe';
                }, 2000);
            }
        }, 8000);
    } else {
        button.innerHTML = '<i class="fas fa-play"></i> Start 4-7-8 Breathing';
        circle.style.animation = 'none';
        circle.querySelector('span').textContent = 'Breathe';
    }
}

// Sleep Rating
function setupSleepRating() {
    const stars = document.querySelectorAll('.stars i');
    stars.forEach(star => {
        star.addEventListener('click', () => {
            const rating = parseInt(star.dataset.rating);
            selectedRating = rating;

            // Update stars display
            stars.forEach((s, index) => {
                if (index < rating) {
                    s.classList.add('fas');
                    s.classList.remove('far');
                } else {
                    s.classList.add('far');
                    s.classList.remove('fas');
                }
            });
        });
    });

    document.getElementById('submitRating').addEventListener('click', () => {
        if (selectedRating > 0) {
            saveSleepRating(selectedRating);
            showNotification('Sleep Rating', `Thank you! You rated your sleep ${selectedRating} stars.`);
            selectedRating = 0;

            // Reset stars
            document.querySelectorAll('.stars i').forEach(star => {
                star.classList.add('fas');
                star.classList.remove('far');
            });
        }
    });
}

function saveSleepRating(rating) {
    const ratings = JSON.parse(localStorage.getItem('sleepRatings') || '[]');
    ratings.push({
        date: new Date().toISOString(),
        rating: rating
    });
    localStorage.setItem('sleepRatings', JSON.stringify(ratings));
}

// Bedtime Reminder
function setBedtimeReminder() {
    const time = document.getElementById('bedtime').value;
    if (!time) return;

    const [hours, minutes] = time.split(':').map(Number);
    const now = new Date();
    const reminderTime = new Date();
    reminderTime.setHours(hours, minutes, 0, 0);

    if (reminderTime <= now) {
        reminderTime.setDate(reminderTime.getDate() + 1);
    }

    const timeUntilReminder = reminderTime - now;

    showNotification('Bedtime Reminder Set',
        `Reminder set for ${time}. You'll be reminded in ${Math.round(timeUntilReminder/60000)} minutes.`);

    setTimeout(() => {
        if (Notification.permission === 'granted') {
            new Notification('🎄 CalmBeforeChristmas', {
                body: 'It\'s bedtime! Time to wind down and get some rest. Sleep well!',
                icon: '🎅'
            });
        }
        showNotification('Bedtime Reminder', 'It\'s bedtime! Time to wind down and get some rest. Sleep well!');
    }, timeUntilReminder);
}

// Anxiety Quiz
function startAnxietyQuiz() {
    const questions = [
        { text: "How tense do you feel right now?", options: ["Not at all", "Slightly", "Moderately", "Very", "Extremely"] },
        { text: "How worried are you about the future?", options: ["Not worried", "Slightly worried", "Somewhat worried", "Very worried", "Extremely worried"] },
        { text: "How difficult is it to relax?", options: ["Not difficult", "Slightly difficult", "Moderately difficult", "Very difficult", "Extremely difficult"] },
        { text: "How restless do you feel?", options: ["Not restless", "Slightly restless", "Moderately restless", "Very restless", "Extremely restless"] },
        { text: "How easily do you become annoyed or irritable?", options: ["Not easily", "Slightly easily", "Moderately easily", "Very easily", "Extremely easily"] },
        { text: "How afraid do you feel?", options: ["Not afraid", "Slightly afraid", "Moderately afraid", "Very afraid", "Extremely afraid"] },
        { text: "How is your sleep quality?", options: ["Excellent", "Good", "Fair", "Poor", "Very poor"] },
        { text: "How is your concentration?", options: ["Excellent", "Good", "Fair", "Poor", "Very poor"] },
        { text: "How fatigued do you feel?", options: ["Not fatigued", "Slightly fatigued", "Moderately fatigued", "Very fatigued", "Extremely fatigued"] },
        { text: "How would you rate your overall stress level?", options: ["Very low", "Low", "Moderate", "High", "Very high"] }
    ];

    const quizContainer = document.getElementById('quizContainer');
    quizContainer.classList.remove('hidden');
    quizContainer.innerHTML = '';

    questions.forEach((q, index) => {
                const questionDiv = document.createElement('div');
                questionDiv.className = 'quiz-question';
                questionDiv.innerHTML = `
            <h4>${index + 1}. ${q.text}</h4>
            ${q.options.map((opt, optIndex) => `
                <label class="quiz-option">
                    <input type="radio" name="q${index}" value="${optIndex}">
                    ${opt}
                </label>
            `).join('')}
        `;
        quizContainer.appendChild(questionDiv);
    });
    
    const submitBtn = document.createElement('button');
    submitBtn.className = 'btn-primary';
    submitBtn.textContent = 'Submit Quiz';
    submitBtn.onclick = calculateAnxietyScore;
    quizContainer.appendChild(submitBtn);
}

function calculateAnxietyScore() {
    const answers = document.querySelectorAll('input[type="radio"]:checked');
    if (answers.length < 10) {
        alert('Please answer all questions.');
        return;
    }
    
    let totalScore = 0;
    answers.forEach(answer => {
        totalScore += parseInt(answer.value) + 1;
    });
    
    let level, message;
    if (totalScore <= 20) {
        level = "Low";
        message = "Your anxiety levels appear to be low. Continue practicing good self-care routines!";
    } else if (totalScore <= 30) {
        level = "Mild";
        message = "You're experiencing mild anxiety. Try some breathing exercises or take a short break.";
    } else if (totalScore <= 40) {
        level = "Moderate";
        message = "You're experiencing moderate anxiety. Consider trying the grounding exercise or listening to calming sounds.";
    } else {
        level = "High";
        message = "You're experiencing high anxiety. Please try the emergency support features and consider reaching out to someone you trust.";
    }
    
    document.getElementById('quizContainer').classList.add('hidden');
    const resultDiv = document.getElementById('quizResult');
    resultDiv.classList.remove('hidden');
    document.getElementById('anxietyLevel').textContent = level;
    document.getElementById('aiResponse').textContent = message;
    
    // Update calm score based on anxiety level
    updateCalmScoreBasedOnAnxiety(level);
}

function updateCalmScoreBasedOnAnxiety(level) {
    const adjustments = { "Low": 10, "Mild": 5, "Moderate": -5, "High": -10 };
    calmScore = Math.max(0, Math.min(100, calmScore + adjustments[level]));
    updateUI();
}

// Emergency Support
function showPanicHelp() {
    const steps = [
        "Find a comfortable place to sit or lie down",
        "Focus on your breathing - try the 4-7-8 technique",
        "Name 5 things you can see around you",
        "Name 4 things you can touch",
        "Name 3 things you can hear",
        "Name 2 things you can smell",
        "Name 1 thing you can taste",
        "Remember: This feeling will pass. You are safe."
    ];
    
    let message = "🚨 **Panic Attack First Aid** 🚨\n\n";
    steps.forEach((step, index) => {
        message += `${index + 1}. ${step}\n`;
    });
    
    message += "\nYou're not alone. This will pass.";
    
    if (confirm("Open panic attack help guide?\n\n" + message)) {
        // Start the grounding exercise automatically
        startGroundingExercise();
    }
}

function showImNotOkaySupport() {
    const supportOptions = [
        "National Suicide Prevention Lifeline: 1-800-273-8255",
        "Crisis Text Line: Text HOME to 741741",
        "Trevor Project (LGBTQ+): 1-866-488-7386",
        "Veterans Crisis Line: 1-800-273-8255",
        "Your campus counseling center",
        "A trusted friend or family member"
    ];
    
    let message = "🫂 **You're Not Alone** 🫂\n\n";
    message += "It takes courage to acknowledge when you're not okay.\n\n";
    message += "**Immediate Support Options:**\n\n";
    supportOptions.forEach(option => {
        message += `• ${option}\n`;
    });
    
    message += "\n**Right now, try:**\n";
    message += "1. Take 5 deep breaths\n";
    message += "2. Drink a glass of water\n";
    message += "3. Step outside for fresh air\n";
    message += "4. Listen to calming sounds\n\n";
    message += "You matter. Your feelings are valid. Help is available.";
    
    alert(message);
}

// Grounding Exercise
function startGroundingExercise() {
    const steps = [
        { title: "5 Things You Can See", desc: "Look around and name 5 things you can see" },
        { title: "4 Things You Can Touch", desc: "Name 4 things you can touch or feel" },
        { title: "3 Things You Can Hear", desc: "Listen carefully and name 3 things you can hear" },
        { title: "2 Things You Can Smell", desc: "Name 2 things you can smell or like the smell of" },
        { title: "1 Thing You Can Taste", desc: "Name 1 thing you can taste or like the taste of" }
    ];
    
    const stepsDiv = document.getElementById('groundingSteps');
    stepsDiv.classList.remove('hidden');
    stepsDiv.innerHTML = '<h4>5-4-3-2-1 Grounding Exercise</h4>';
    
    let currentStep = 0;
    
    function showNextStep() {
        if (currentStep >= steps.length) {
            stepsDiv.innerHTML += '<div class="grounding-step"><strong>✅ Exercise Complete!</strong><br>You are here. You are safe. This moment will pass.</div>';
            return;
        }
        
        const step = steps[currentStep];
        const stepDiv = document.createElement('div');
        stepDiv.className = 'grounding-step';
        stepDiv.innerHTML = `<strong>${step.title}</strong><br>${step.desc}`;
        
        if (currentStep > 0) {
            stepsDiv.removeChild(stepsDiv.lastChild);
        }
        stepsDiv.appendChild(stepDiv);
        
        currentStep++;
        
        // Auto-advance after 15 seconds
        setTimeout(showNextStep, 15000);
    }
    
    showNextStep();
}

// Mood Tracker
function setupMoodTracker() {
    document.querySelectorAll('.mood-option').forEach(option => {
        option.addEventListener('click', function() {
            currentMood = parseInt(this.dataset.mood);
            document.querySelectorAll('.mood-option').forEach(opt => {
                opt.style.transform = '';
                opt.style.background = '';
            });
            this.style.transform = 'translateY(-10px)';
            this.style.background = 'rgba(46, 125, 50, 0.2)';
        });
    });
    
    document.getElementById('logMood').addEventListener('click', function() {
        const moods = ['😢 Sad', '😔 Low', '😐 Okay', '🙂 Good', '😊 Great'];
        const moodText = moods[currentMood - 1];
        
        // Save mood to local storage
        const moodLog = JSON.parse(localStorage.getItem('moodLog') || '[]');
        moodLog.push({
            date: new Date().toISOString(),
            mood: currentMood,
            score: calmScore
        });
        localStorage.setItem('moodLog', JSON.stringify(moodLog));
        
        // Update streak
        updateStreak();
        
        showNotification('Mood Logged', `Your mood (${moodText}) has been logged. Thank you for checking in!`);
        
        // Update calm score
        calmScore = Math.min(100, calmScore + 5);
        updateUI();
    });
}

// Festive Features
async function generateSantaMessage() {
    const messages = [
        "🎅 Ho ho ho! Remember to take deep breaths when feeling stressed. You're doing great!",
        "🎄 The greatest gift you can give yourself this season is peace of mind. Take time to relax.",
        "🦌 Just like reindeer need rest after a long flight, your mind needs breaks too. Schedule some quiet time today.",
        "🎁 Your mental health is the most important present under the tree. Unwrap some self-care today!",
        "❄️ Like snowflakes, every breath is unique and precious. Take a moment to breathe mindfully.",
        "🕯️ Let the warmth of self-compassion melt away your worries. You deserve kindness, especially from yourself.",
        "🔔 When anxiety rings loudly, answer with a deep breath. You have the power to calm the noise.",
        "🌟 You shine brighter than any star on the tree. Remember your worth during stressful times."
    ];
    
    // Try to get AI-generated message first
    try {
        const aiMessage = await getAIMessage("Generate a short, festive, comforting message about mental health for a student during the holidays");
        if (aiMessage) {
            document.getElementById('dailyMessage').textContent = "🎅 " + aiMessage;
            return;
        }
    } catch (error) {
        console.log("Using fallback messages");
    }
    
    // Fallback to predefined messages
    const randomMessage = messages[Math.floor(Math.random() * messages.length)];
    document.getElementById('dailyMessage').textContent = randomMessage;
}

function generateNewQuote() {
    const quotes = [
        "Peace is the greatest gift of all. Breathe in calm, breathe out stress.",
        "Your mind is a garden. Nourish it with kindness, water it with rest.",
        "One peaceful thought at a time, one calm breath at a time.",
        "The present moment is your safe place. Anchor yourself here.",
        "You are stronger than your stress, brighter than your worries.",
        "Rest is not a reward for finishing everything. Rest is part of the process.",
        "Your feelings are valid. Your need for peace is important.",
        "Like a snowflake, you are unique, beautiful, and temporary. This moment will pass.",
        "Self-care isn't selfish. It's how you recharge to be there for others.",
        "You don't have to be perfect to be worthy of peace and rest."
    ];
    
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    document.getElementById('currentQuote').textContent = `"${randomQuote}"`;
}

// AI Support
async function getAIResponse() {
    const input = document.getElementById('aiInput').value.trim();
    if (!input) {
        alert("Please share how you're feeling first.");
        return;
    }
    
    const responseBox = document.getElementById('aiSupportResponse');
    responseBox.textContent = "Thinking of a calming response... 🎄";
    
    try {
        const prompt = `As a mental health support assistant during the holiday season, provide a comforting, supportive response to this student's feelings: "${input}". Keep it under 100 words, warm, and festive. Include a practical calming suggestion.`;
        
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [{ text: prompt }]
                }]
            })
        });
        
        const data = await response.json();
        if (data.candidates && data.candidates[0].content.parts[0].text) {
            responseBox.textContent = data.candidates[0].content.parts[0].text;
        } else {
            throw new Error('No response from AI');
        }
    } catch (error) {
        console.error('AI Error:', error);
        // Fallback responses
        const fallbacks = [
            "I hear you. During stressful times, remember to take things one breath at a time. Try the 4-7-8 breathing exercise - it can help calm your nervous system.",
            "Thank you for sharing. The holidays can be overwhelming. Remember, it's okay to take breaks and prioritize your peace. Maybe try listening to some calming sounds?",
            "Your feelings matter. When things feel heavy, try the 5-4-3-2-1 grounding exercise. It can help bring you back to the present moment.",
            "I understand this is difficult. Remember that like snowflakes, difficult moments are temporary. This too shall pass. Be gentle with yourself."
        ];
        responseBox.textContent = fallbacks[Math.floor(Math.random() * fallbacks.length)];
    }
}

async function getAIMessage(prompt) {
    try {
        const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{
                    parts: [{ text: prompt }]
                }],
                generationConfig: {
                    maxOutputTokens: 100
                }
            })
        });
        
        const data = await response.json();
        return data.candidates?.[0]?.content?.parts?.[0]?.text || null;
    } catch (error) {
        return null;
    }
}

// Reports
function showWeeklyReport() {
    const moodLog = JSON.parse(localStorage.getItem('moodLog') || '[]');
    const sleepRatings = JSON.parse(localStorage.getItem('sleepRatings') || '[]');
    
    let report = "📊 **Your Weekly Wellness Report** 📊\n\n";
    report += `🎯 Current Calm Score: ${calmScore}/100\n`;
    report += `🔥 Current Streak: ${streak} days\n\n`;
    
    if (moodLog.length > 0) {
        report += "📈 **Mood Trends:**\n";
        const lastWeekMoods = moodLog.slice(-7);
        lastWeekMoods.forEach(log => {
            const date = new Date(log.date).toLocaleDateString();
            const moodEmoji = ['😢', '😔', '😐', '🙂', '😊'][log.mood - 1];
            report += `${date}: ${moodEmoji} (Score: ${log.score})\n`;
        });
    }
    
    if (sleepRatings.length > 0) {
        report += "\n😴 **Sleep Quality:**\n";
        const avgSleepRating = sleepRatings.reduce((acc, curr) => acc + curr.rating, 0) / sleepRatings.length;
        report += `Average Sleep Rating: ${avgSleepRating.toFixed(1)}/5 stars\n`;
    }
    
    report += "\n🎄 **Personalized Suggestions:**\n";
    if (calmScore < 50) {
        report += "- Try the daily anxiety check-in\n";
        report += "- Practice the 4-7-8 breathing exercise daily\n";
        report += "- Set a consistent bedtime routine\n";
    } else {
        report += "- Great job maintaining your calm!\n";
        report += "- Continue with your current routines\n";
        report += "- Share your techniques with friends\n";
    }
    
    alert(report);
}

function exportReport() {
    const moodLog = JSON.parse(localStorage.getItem('moodLog') || '[]');
    const sleepRatings = JSON.parse(localStorage.getItem('sleepRatings') || '[]');
    
    let reportContent = `
        CalmBeforeChristmas - Mental Wellness Report
        Generated on: ${new Date().toLocaleDateString()}
        =====================================================
        
        SUMMARY
        - Current Calm Score: ${calmScore}/100
        - Current Streak: ${streak} days
        - Mood Entries: ${moodLog.length}
        - Sleep Ratings: ${sleepRatings.length}
        
        MOOD LOG
        ${moodLog.map(log => `${new Date(log.date).toLocaleDateString()} | Mood: ${log.mood}/5 | Score: ${log.score}`).join('\n')}
        
        SLEEP RATINGS
        ${sleepRatings.map(r => `${new Date(r.date).toLocaleDateString()} | Rating: ${r.rating}/5 stars`).join('\n')}
        
        RECOMMENDATIONS
        ${calmScore < 50 ? 
            '1. Practice daily breathing exercises\n2. Establish consistent sleep schedule\n3. Use grounding techniques when anxious' :
            '1. Maintain current healthy routines\n2. Share wellness practices with others\n3. Continue regular check-ins'
        }
        
        Remember: Mental wellness is a journey, not a destination.
        Be kind to yourself, especially during stressful times.
        🎄 CalmBeforeChristmas 🎄
    `;
    
    // Create download link
    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `CalmReport_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    showNotification('Report Exported', 'Your wellness report has been downloaded.');
}

// Streak System
function updateStreak() {
    const lastLogin = localStorage.getItem('lastLogin');
    const today = new Date().toDateString();
    
    if (lastLogin === today) {
        return; // Already logged today
    }
    
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (lastLogin === yesterday.toDateString()) {
        streak = parseInt(localStorage.getItem('streak') || '0') + 1;
    } else if (!lastLogin) {
        streak = 1;
    } else {
        streak = 1; // Broken streak
    }
    
    localStorage.setItem('streak', streak.toString());
    localStorage.setItem('lastLogin', today);
    
    // Award badges based on streak
    updateBadges();
}

function updateBadges() {
    if (streak >= 3) {
        document.getElementById('streakBadge').style.opacity = '1';
    }
}

// UI Updates
function updateUI() {
    document.getElementById('calmScore').textContent = calmScore;
    document.getElementById('streakCount').textContent = streak;
    
    // Update calm score circle
    const scoreCircle = document.querySelector('.score-circle');
    scoreCircle.style.background = `conic-gradient(var(--christmas-green) ${calmScore}%, #e0e0e0 0%)`;
    
    // Update badges based on calm score
    if (calmScore >= 80) {
        document.getElementById('calmBadge').style.opacity = '1';
    }
}

// Local Storage
function saveToLocalStorage() {
    const data = {
        calmScore,
        streak,
        isNightMode,
        snowEnabled,
        currentMood
    };
    localStorage.setItem('calmAppData', JSON.stringify(data));
}

function loadFromLocalStorage() {
    const saved = JSON.parse(localStorage.getItem('calmAppData') || '{}');
    calmScore = saved.calmScore || 75;
    streak = saved.streak || 0;
    isNightMode = saved.isNightMode || false;
    snowEnabled = saved.snowEnabled !== false;
    currentMood = saved.currentMood || 3;
    
    if (isNightMode) {
        document.body.classList.add('night-mode');
    }
}

// Notifications
function showNotification(title, message) {
    // Check if browser supports notifications
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(title, {
            body: message,
            icon: '🎄'
        });
    }
    
    // Also show as alert for browsers without notification support
    console.log(`${title}: ${message}`);
}